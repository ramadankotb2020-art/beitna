const DEFAULT_CATEGORIES = [
  "أكل وشرب", "بقالة والبيت", "مواصلات وبنزين", "فواتير",
  "إيجار", "صحة ودوا", "تعليم", "لبس", "موبايل وإنترنت",
  "خروج", "هدايا ومناسبات", "مصروف شخصي", "أخرى",
];

const SCHEMA = `
CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, name TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS incomes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  kind TEXT NOT NULL DEFAULT 'fixed',
  month TEXT,
  owner TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  month TEXT NOT NULL,
  date TEXT NOT NULL,
  category TEXT,
  note TEXT,
  amount REAL NOT NULL DEFAULT 0,
  owner TEXT,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS debts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  direction TEXT NOT NULL DEFAULT 'out',
  total REAL NOT NULL DEFAULT 0,
  installment REAL NOT NULL DEFAULT 0,
  due_day INTEGER,
  start_month TEXT,
  notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS debt_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  debt_id INTEGER NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  date TEXT NOT NULL,
  month TEXT NOT NULL,
  owner TEXT,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS savings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  target REAL NOT NULL DEFAULT 0,
  owner TEXT,
  notes TEXT,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS savings_tx (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  goal_id INTEGER NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  kind TEXT NOT NULL DEFAULT 'deposit',
  date TEXT NOT NULL,
  month TEXT NOT NULL,
  owner TEXT,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS login_attempts (
  ip TEXT PRIMARY KEY,
  fails INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT
);
`;

let schemaReady = null;

function json(obj, status = 200, headers = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...headers,
    },
  });
}

function rnd(x) {
  return Math.round((Number(x) || 0) * 100) / 100;
}

function cairoNow(date = new Date()) {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "Africa/Cairo",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23",
    }).formatToParts(date).map((p) => [p.type, p.value])
  );
  const day = `${parts.year}-${parts.month}-${parts.day}`;
  return { day, iso: `${day}T${parts.hour}:${parts.minute}:${parts.second}` };
}

function okMonth(m) {
  if (!m || m.length !== 7 || m[4] !== "-") return false;
  const y = Number(m.slice(0, 4));
  const mo = Number(m.slice(5));
  return y > 1900 && y < 2200 && mo >= 1 && mo <= 12;
}

function cleanDate(value, fallback) {
  const s = String(value || "").slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    const d = new Date(s + "T00:00:00Z");
    if (!Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s) return s;
  }
  return fallback;
}

function parseAmount(value, allowZero = false) {
  const n = Math.round(Number(value === undefined || value === null || value === "" ? 0 : value) * 100) / 100;
  if (!Number.isFinite(n) || n < 0 || n > 1_000_000_000) throw new Error("اكتب مبلغ صحيح");
  if (n === 0 && !allowZero) throw new Error("اكتب مبلغ صحيح");
  return n;
}

function clip(value, n, fallback = "") {
  const s = String(value ?? fallback).trim();
  return s.slice(0, n);
}

function reqId(value) {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw new Error("رقم غير صحيح");
  return n;
}

function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const len = Math.max(a.length, b.length);
  let diff = a.length === b.length ? 0 : 1;
  for (let i = 0; i < len; i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  return diff === 0;
}

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function randomToken(bytes = 24) {
  const raw = new Uint8Array(bytes);
  crypto.getRandomValues(raw);
  return btoa(String.fromCharCode(...raw)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function ensureSchema(db) {
  if (!schemaReady) {
    const statements = SCHEMA.split(";").map((s) => s.trim()).filter(Boolean);
    schemaReady = (async () => {
      for (const sql of statements) await db.prepare(sql).run();
    })().catch((err) => {
      schemaReady = null;
      throw err;
    });
  }
  await schemaReady;
}

async function getSetting(db, key, fallback = null) {
  const row = await db.prepare("SELECT v FROM settings WHERE k = ?").bind(key).first();
  return row ? row.v : fallback;
}

async function setSetting(db, key, value) {
  const v = typeof value === "string" ? value : JSON.stringify(value);
  await db.prepare(
    "INSERT INTO settings(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v"
  ).bind(key, v).run();
}

async function membersOf(db) {
  const raw = await getSetting(db, "members");
  try {
    const m = raw ? JSON.parse(raw) : ["أنا", "زوجتي"];
    return Array.isArray(m) && m.length >= 2 ? m.slice(0, 2) : ["أنا", "زوجتي"];
  } catch {
    return ["أنا", "زوجتي"];
  }
}

async function categoriesOf(db) {
  const raw = await getSetting(db, "categories");
  if (!raw) return DEFAULT_CATEGORIES.slice();
  try {
    const list = JSON.parse(raw);
    return Array.isArray(list) && list.length ? list : DEFAULT_CATEGORIES.slice();
  } catch {
    return DEFAULT_CATEGORIES.slice();
  }
}

async function limitsOf(db) {
  const raw = await getSetting(db, "limits");
  if (!raw) return {};
  try {
    const obj = JSON.parse(raw);
    return obj && typeof obj === "object" ? obj : {};
  } catch {
    return {};
  }
}

async function buildState(db, month) {
  const [incomesRes, expensesRes, debtsRes, paysRes, goalsRes, txsRes, hh, members, categories, limits, hint] = await Promise.all([
    db.prepare("SELECT * FROM incomes ORDER BY id DESC").all(),
    db.prepare("SELECT * FROM expenses WHERE month = ? ORDER BY date DESC, id DESC").bind(month).all(),
    db.prepare("SELECT * FROM debts ORDER BY CASE direction WHEN 'out' THEN 0 ELSE 1 END, active DESC, id DESC").all(),
    db.prepare("SELECT * FROM debt_payments ORDER BY date DESC, id DESC").all(),
    db.prepare("SELECT * FROM savings ORDER BY id DESC").all(),
    db.prepare("SELECT * FROM savings_tx ORDER BY date DESC, id DESC").all(),
    getSetting(db, "hh", "بيتنا"),
    membersOf(db),
    categoriesOf(db),
    limitsOf(db),
    getSetting(db, "hint", ""),
  ]);

  const incomes = incomesRes.results || [];
  const expenses = expensesRes.results || [];
  const debts = debtsRes.results || [];
  const pays = paysRes.results || [];
  const goals = goalsRes.results || [];
  const txs = txsRes.results || [];

  const paidTotal = {};
  const paidMonth = {};
  for (const p of pays) {
    paidTotal[p.debt_id] = (paidTotal[p.debt_id] || 0) + (p.amount || 0);
    if (p.month === month) paidMonth[p.debt_id] = (paidMonth[p.debt_id] || 0) + (p.amount || 0);
  }
  const paysBy = {};
  for (const p of pays) {
    const bucket = paysBy[p.debt_id] || (paysBy[p.debt_id] = []);
    if (bucket.length < 6) bucket.push(p);
  }
  for (const d of debts) {
    d.paid_total = rnd(paidTotal[d.id] || 0);
    d.remaining = rnd(Math.max((d.total || 0) - d.paid_total, 0));
    d.paid_this_month = rnd(paidMonth[d.id] || 0);
    const inst = d.installment || 0;
    let due = 0;
    if (d.active && inst > 0 && d.remaining > 0 && (!d.start_month || d.start_month <= month)) {
      due = Math.min(inst, d.remaining);
    }
    d.due_this_month = rnd(due);
    d.due_left = rnd(Math.max(due - d.paid_this_month, 0));
    d.progress = d.total ? Math.round((1000 * Math.min(d.paid_total, d.total)) / d.total) / 10 : 0;
    d.payments = paysBy[d.id] || [];
  }

  const savedTotal = {};
  const savedMonth = {};
  for (const t of txs) {
    const sign = t.kind === "deposit" ? 1 : -1;
    savedTotal[t.goal_id] = (savedTotal[t.goal_id] || 0) + sign * (t.amount || 0);
    if (t.month === month) savedMonth[t.goal_id] = (savedMonth[t.goal_id] || 0) + sign * (t.amount || 0);
  }
  const txsBy = {};
  for (const t of txs) {
    const bucket = txsBy[t.goal_id] || (txsBy[t.goal_id] = []);
    if (bucket.length < 6) bucket.push(t);
  }
  for (const g of goals) {
    g.saved = rnd(savedTotal[g.id] || 0);
    g.saved_this_month = rnd(savedMonth[g.id] || 0);
    g.progress = g.target ? Math.round((1000 * g.saved) / g.target) / 10 : 0;
    g.recent = txsBy[g.id] || [];
  }

  const incomeMonth = incomes.reduce((sum, i) => {
    if (!i.active) return sum;
    if (i.kind === "fixed" && (!i.month || i.month <= month)) return sum + (i.amount || 0);
    if (i.kind === "once" && i.month === month) return sum + (i.amount || 0);
    return sum;
  }, 0);
  const expensesMonth = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const owed = debts.filter((d) => d.direction === "out" && d.active);
  const recv = debts.filter((d) => d.direction === "in" && d.active);
  const installDue = owed.reduce((s, d) => s + d.due_this_month, 0);
  const installLeft = owed.reduce((s, d) => s + d.due_left, 0);
  const installPaid = owed.reduce((s, d) => s + d.paid_this_month, 0);
  const collections = recv.reduce((s, d) => s + d.paid_this_month, 0);
  const savingsMonth = goals.reduce((s, g) => s + g.saved_this_month, 0);
  const spentByCat = {};
  for (const e of expenses) {
    const k = e.category || "أخرى";
    spentByCat[k] = (spentByCat[k] || 0) + (e.amount || 0);
  }
  const net = incomeMonth - expensesMonth - installPaid - savingsMonth + collections;
  const iOwe = owed.reduce((s, d) => s + d.remaining, 0);
  const theyOwe = recv.reduce((s, d) => s + d.remaining, 0);
  const savingsAll = goals.reduce((s, g) => s + g.saved, 0);

  return {
    month,
    incomes,
    expenses,
    debts,
    savings: goals,
    savings_tx: txs.filter((t) => t.month === month),
    totals: {
      income_month: rnd(incomeMonth),
      expenses_month: rnd(expensesMonth),
      install_due: rnd(installDue),
      install_paid: rnd(installPaid),
      install_left: rnd(installLeft),
      collections_month: rnd(collections),
      savings_month: rnd(savingsMonth),
      savings_all: rnd(savingsAll),
      net_month: rnd(net),
      projected_left: rnd(net - installLeft),
      i_owe: rnd(iOwe),
      they_owe: rnd(theyOwe),
      position: rnd(theyOwe - iOwe),
      spent_by_cat: Object.fromEntries(Object.entries(spentByCat).map(([k, v]) => [k, rnd(v)])),
    },
    settings: {
      hh: hh || "بيتنا",
      members,
      categories,
      limits,
      hint: hint || "",
    },
  };
}

async function authName(db, request) {
  const token = request.headers.get("x-token") || "";
  if (!token) return null;
  const row = await db.prepare("SELECT name FROM sessions WHERE token = ?").bind(token).first();
  return row ? row.name : null;
}

function clientIp(request) {
  return request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for") || "local";
}

async function loginBlocked(db, ip) {
  const row = await db.prepare("SELECT fails, locked_until FROM login_attempts WHERE ip = ?").bind(ip).first();
  if (!row || !row.locked_until) return false;
  if (row.locked_until > new Date().toISOString()) return true;
  await db.prepare("UPDATE login_attempts SET fails = 0, locked_until = NULL WHERE ip = ?").bind(ip).run();
  return false;
}

async function noteLoginFail(db, ip) {
  const row = await db.prepare("SELECT fails FROM login_attempts WHERE ip = ?").bind(ip).first();
  const fails = (row?.fails || 0) + 1;
  const locked = fails >= 8 ? new Date(Date.now() + 15 * 60 * 1000).toISOString() : null;
  await db.prepare(
    "INSERT INTO login_attempts(ip, fails, locked_until) VALUES(?, ?, ?) ON CONFLICT(ip) DO UPDATE SET fails = excluded.fails, locked_until = excluded.locked_until"
  ).bind(ip, fails, locked).run();
}

async function readBody(request) {
  const len = Number(request.headers.get("content-length") || 0);
  if (len > 100_000) throw new Error("الطلب كبير");
  const text = await request.text();
  if (!text) return {};
  if (text.length > 100_000) throw new Error("الطلب كبير");
  try {
    const data = JSON.parse(text);
    return data && typeof data === "object" ? data : {};
  } catch {
    return {};
  }
}

async function handleApi(request, env) {
  if (!env.DB) {
    return json({ error: "قاعدة البيانات مش متوصلة. من إعدادات الووركر اربط D1 باسم DB." }, 500);
  }
  await ensureSchema(env.DB);
  const url = new URL(request.url);
  const path = url.pathname;
  const db = env.DB;
  const now = cairoNow();

  if (request.method === "GET" && path === "/api/status") {
    const hash = await getSetting(db, "code_hash");
    return json({
      needs_setup: !hash,
      hh: (await getSetting(db, "hh", "بيتنا")) || "بيتنا",
      members: await membersOf(db),
      hint: (await getSetting(db, "hint")) || "",
    });
  }

  if (request.method === "GET" && (path === "/api/state" || path === "/api/export")) {
    const name = await authName(db, request);
    if (!name) return json({ error: "unauthorized" }, 401);
    let month = url.searchParams.get("month") || now.day.slice(0, 7);
    if (!okMonth(month)) month = now.day.slice(0, 7);
    const state = await buildState(db, month);
    state.me = name;
    if (path === "/api/export") {
      return new Response(JSON.stringify(state, null, 2), {
        headers: {
          "content-type": "application/json; charset=utf-8",
          "content-disposition": 'attachment; filename="beitna-backup.json"',
          "cache-control": "no-store",
        },
      });
    }
    return json(state);
  }

  if (request.method === "POST" && path === "/api/setup") {
    if (await getSetting(db, "code_hash")) return json({ error: "already_setup" }, 400);
    const data = await readBody(request);
    const code = String(data.code || "").trim();
    if (code.length < 6) return json({ error: "الكود لازم 6 أرقام أو أكتر" }, 400);
    let mem = Array.isArray(data.members) ? data.members.slice(0, 2) : ["أنا", "زوجتي"];
    mem = mem.map((m, i) => clip(m, 40) || `فرد ${i + 1}`);
    while (mem.length < 2) mem.push(`فرد ${mem.length + 1}`);
    const salt = randomToken(8);
    await setSetting(db, "salt", salt);
    await setSetting(db, "code_hash", await sha256(`${salt}::${code}`));
    await setSetting(db, "members", mem);
    await setSetting(db, "hh", clip(data.hh, 40) || "بيتنا");
    if (data.hint) await setSetting(db, "hint", clip(data.hint, 80));
    return json({ ok: true, members: mem });
  }

  if (request.method === "POST" && path === "/api/login") {
    const ip = clientIp(request);
    if (await loginBlocked(db, ip)) return json({ error: "محاولات كتير. استنوا ربع ساعة." }, 429);
    const data = await readBody(request);
    const code = String(data.code || "").trim();
    const salt = await getSetting(db, "salt");
    const stored = await getSetting(db, "code_hash");
    const ok = salt && stored && safeEqual(await sha256(`${salt}::${code}`), stored);
    if (!ok) {
      await noteLoginFail(db, ip);
      return json({ error: "كود غلط، جرّب تاني" }, 401);
    }
    await db.prepare("DELETE FROM login_attempts WHERE ip = ?").bind(ip).run();
    const people = await membersOf(db);
    const name = clip(data.name, 40) || people[0];
    const token = randomToken(24);
    await db.prepare("INSERT INTO sessions(token, name, created_at) VALUES(?, ?, ?)").bind(token, name, now.iso).run();
    return json({ token, name, hh: (await getSetting(db, "hh", "بيتنا")) || "بيتنا" });
  }

  if (request.method === "DELETE") {
    const name = await authName(db, request);
    if (!name) return json({ error: "unauthorized" }, 401);
    const parts = path.split("/").filter(Boolean);
    const tables = {
      expense: "expenses",
      income: "incomes",
      debt: "debts",
      saving: "savings",
      payment: "debt_payments",
      savingtx: "savings_tx",
    };
    if (parts.length === 3 && parts[0] === "api" && tables[parts[1]]) {
      const id = reqId(parts[2]);
      const table = tables[parts[1]];
      if (table === "debts") await db.prepare("DELETE FROM debt_payments WHERE debt_id = ?").bind(id).run();
      if (table === "savings") await db.prepare("DELETE FROM savings_tx WHERE goal_id = ?").bind(id).run();
      await db.prepare(`DELETE FROM ${table} WHERE id = ?`).bind(id).run();
      return json({ ok: true });
    }
    return json({ error: "not found" }, 404);
  }

  if (request.method !== "POST") return json({ error: "not found" }, 404);

  const name = await authName(db, request);
  if (!name) return json({ error: "unauthorized" }, 401);
  if (path === "/api/logout") {
    await db.prepare("DELETE FROM sessions WHERE token = ?").bind(request.headers.get("x-token") || "").run();
    return json({ ok: true });
  }

  const data = await readBody(request);
  const today = now.day;

  if (path === "/api/expense") {
    const amount = parseAmount(data.amount);
    const date = cleanDate(data.date, today);
    const result = await db.prepare(
      "INSERT INTO expenses(month, date, category, note, amount, owner, created_at) VALUES(?, ?, ?, ?, ?, ?, ?)"
    ).bind(date.slice(0, 7), date, clip(data.category, 40, "أخرى") || "أخرى", clip(data.note, 160), amount, clip(data.owner, 40) || name, now.iso).run();
    return json({ ok: true, id: result.meta?.last_row_id || null });
  }

  if (path === "/api/income") {
    const amount = parseAmount(data.amount);
    const kind = data.kind === "once" ? "once" : "fixed";
    let month = String(data.month || today.slice(0, 7)).slice(0, 7);
    if (!okMonth(month)) month = today.slice(0, 7);
    const result = await db.prepare(
      "INSERT INTO incomes(name, amount, kind, month, owner, active, created_at) VALUES(?, ?, ?, ?, ?, 1, ?)"
    ).bind(clip(data.name, 80, "دخل") || "دخل", amount, kind, month, clip(data.owner, 40) || name, now.iso).run();
    return json({ ok: true, id: result.meta?.last_row_id || null });
  }

  if (path === "/api/debt") {
    const total = parseAmount(data.total);
    const inst = parseAmount(data.installment, true);
    let due = parseInt(data.due_day || 0, 10);
    if (!Number.isFinite(due) || due < 1 || due > 31) due = 0;
    let start = String(data.start_month || today.slice(0, 7)).slice(0, 7);
    if (!okMonth(start)) start = today.slice(0, 7);
    const result = await db.prepare(
      "INSERT INTO debts(name, direction, total, installment, due_day, start_month, notes, active, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, 1, ?)"
    ).bind(
      clip(data.name, 80, "التزام") || "التزام",
      data.direction === "in" ? "in" : "out",
      total,
      inst,
      due || null,
      start,
      clip(data.notes, 200),
      now.iso
    ).run();
    return json({ ok: true, id: result.meta?.last_row_id || null });
  }

  if (path === "/api/savings") {
    const result = await db.prepare(
      "INSERT INTO savings(name, target, owner, notes, created_at) VALUES(?, ?, ?, ?, ?)"
    ).bind(
      clip(data.name, 80, "مدخرات") || "مدخرات",
      parseAmount(data.target, true),
      clip(data.owner, 40) || name,
      clip(data.notes, 200),
      now.iso
    ).run();
    return json({ ok: true, id: result.meta?.last_row_id || null });
  }

  if (path === "/api/pay") {
    const amount = parseAmount(data.amount);
    const date = cleanDate(data.date, today);
    const id = reqId(data.id);
    let result;
    if (data.what === "debt") {
      result = await db.prepare(
        "INSERT INTO debt_payments(debt_id, amount, date, month, owner, created_at) VALUES(?, ?, ?, ?, ?, ?)"
      ).bind(id, amount, date, date.slice(0, 7), name, now.iso).run();
    } else if (data.what === "saving") {
      const txKind = data.tx_kind === "withdraw" ? "withdraw" : "deposit";
      result = await db.prepare(
        "INSERT INTO savings_tx(goal_id, amount, kind, date, month, owner, created_at) VALUES(?, ?, ?, ?, ?, ?, ?)"
      ).bind(id, amount, txKind, date, date.slice(0, 7), name, now.iso).run();
    } else {
      return json({ error: "نوع غير معروف" }, 400);
    }
    return json({ ok: true, id: result.meta?.last_row_id || null });
  }

  if (path === "/api/update") {
    const id = reqId(data.id);
    if (data.what === "expense") {
      const date = cleanDate(data.date, today);
      await db.prepare(
        "UPDATE expenses SET amount = ?, date = ?, month = ?, category = ?, note = ?, owner = ? WHERE id = ?"
      ).bind(parseAmount(data.amount), date, date.slice(0, 7), clip(data.category, 40, "أخرى") || "أخرى", clip(data.note, 160), clip(data.owner, 40) || name, id).run();
    } else if (data.what === "income") {
      let month = String(data.month || today.slice(0, 7)).slice(0, 7);
      if (!okMonth(month)) month = today.slice(0, 7);
      const active = data.active === 0 || data.active === false || data.active === "0" ? 0 : 1;
      await db.prepare(
        "UPDATE incomes SET name = ?, amount = ?, kind = ?, month = ?, owner = ?, active = ? WHERE id = ?"
      ).bind(clip(data.name, 80, "دخل") || "دخل", parseAmount(data.amount), data.kind === "once" ? "once" : "fixed", month, clip(data.owner, 40) || name, active, id).run();
    } else if (data.what === "debt") {
      let due = parseInt(data.due_day || 0, 10);
      if (!Number.isFinite(due) || due < 1 || due > 31) due = 0;
      const start = String(data.start_month || "").slice(0, 7);
      await db.prepare(
        "UPDATE debts SET name = ?, direction = ?, total = ?, installment = ?, due_day = ?, start_month = ?, notes = ? WHERE id = ?"
      ).bind(
        clip(data.name, 80, "التزام") || "التزام",
        data.direction === "in" ? "in" : "out",
        parseAmount(data.total),
        parseAmount(data.installment, true),
        due || null,
        okMonth(start) ? start : null,
        clip(data.notes, 200),
        id
      ).run();
    } else if (data.what === "saving") {
      await db.prepare("UPDATE savings SET name = ?, target = ?, notes = ? WHERE id = ?").bind(
        clip(data.name, 80, "مدخرات") || "مدخرات",
        parseAmount(data.target, true),
        clip(data.notes, 200),
        id
      ).run();
    } else {
      return json({ error: "نوع غير معروف" }, 400);
    }
    return json({ ok: true });
  }

  if (path === "/api/settings") {
    if (data.new_code && String(data.new_code).trim().length < 6) {
      return json({ error: "الكود لازم 6 أرقام أو أكتر" }, 400);
    }
    if ("hh" in data) await setSetting(db, "hh", clip(data.hh, 40) || "بيتنا");
    if ("hint" in data) await setSetting(db, "hint", clip(data.hint, 80));
    if (Array.isArray(data.members)) {
      const old = await membersOf(db);
      const next = [];
      for (let i = 0; i < 2; i++) {
        next.push(clip(data.members[i], 40) || old[i] || `فرد ${i + 1}`);
      }
      await setSetting(db, "members", next);
      const stmts = [];
      for (let i = 0; i < old.length; i++) {
        if (old[i] && next[i] && old[i] !== next[i]) {
          for (const table of ["expenses", "incomes", "savings", "debt_payments", "savings_tx"]) {
            stmts.push(db.prepare(`UPDATE ${table} SET owner = ? WHERE owner = ?`).bind(next[i], old[i]));
          }
          stmts.push(db.prepare("UPDATE sessions SET name = ? WHERE name = ?").bind(next[i], old[i]));
        }
      }
      if (stmts.length) await db.batch(stmts);
    }
    if (Array.isArray(data.categories)) {
      const cats = [];
      for (const item of data.categories) {
        const s = clip(item, 40);
        if (s && !cats.includes(s)) cats.push(s);
      }
      if (cats.length) await setSetting(db, "categories", cats);
    }
    if (data.limits && typeof data.limits === "object") {
      const clean = {};
      for (const [k, v] of Object.entries(data.limits)) {
        const n = Math.round(Number(v || 0) * 100) / 100;
        if (Number.isFinite(n) && n > 0) clean[String(k).slice(0, 40)] = n;
      }
      await setSetting(db, "limits", clean);
    }
    if (data.new_code) {
      const code = String(data.new_code).trim();
      const salt = randomToken(8);
      await setSetting(db, "salt", salt);
      await setSetting(db, "code_hash", await sha256(`${salt}::${code}`));
    }
    return json({ ok: true });
  }

  return json({ error: "not found" }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      try {
        return await handleApi(request, env);
      } catch (err) {
        console.error("API", err && err.stack ? err.stack : err);
        const message = err && /[\u0600-\u06FF]/.test(err.message || "") ? err.message : "حصل خطأ، جرّب تاني";
        return json({ error: message }, 400);
      }
    }
    if (!env.ASSETS) return new Response("الملف مش موجود", { status: 500 });
    return env.ASSETS.fetch(request);
  },
};
